package project.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	public void addUser(UserLogin user)
	{
		userRepository.save(user);
	}
	public List<UserLogin> getAllUsers(){
		
		List<UserLogin> users=new ArrayList<>();
		userRepository.findAll().forEach(users::add);
		return users;
	
	}
	public UserLogin getUserByEmail(String email)
	{
		return userRepository.findById(email).get();
	}
	public void updateUser(UserLogin user)
	{
		userRepository.save(user);
	}

}
