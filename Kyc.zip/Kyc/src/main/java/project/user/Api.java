package project.user;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
public class Api {
	@Autowired
	private UserService UserService;
	@RequestMapping(method=RequestMethod.POST,value="/users")
	public void addUser(@RequestBody UserLogin user)
	{
	System.out.println(user.getEmail());
	System.out.println(user.getPassword());
		UserService.addUser(user);
	}
	@RequestMapping("/users")
	public List<UserLogin> getAllTopics()
	{
		
		return  UserService.getAllUsers();
	}
	@RequestMapping("/users/{id}")
	public UserLogin getUserByEmail(@PathVariable String id)
	{
		return UserService.getUserByEmail(id);
	}
	@RequestMapping(method=RequestMethod.PUT,value="/users")
    public void updateUser(@RequestBody UserLogin user)
    {
		UserService.updateUser(user);
    }
}


