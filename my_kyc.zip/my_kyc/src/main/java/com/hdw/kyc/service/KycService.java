package com.hdw.kyc.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hdw.kyc.model.Kyc;
import com.hdw.kyc.repository.KycRepository;


@Service
public class KycService {
        @Autowired
        private KycRepository kycrepository;
        public Kyc addUser(Kyc user)
        {
                return kycrepository.save(user);
        }
        public List<Kyc> getAllUsers(){
                
                List<Kyc> users=new ArrayList<>();
                kycrepository.findAll().forEach(users::add);
                return users;
        
        }
        
        public Kyc updateSingleUser(Kyc User)
        {
        	return kycrepository.save(User);
        	
        }
		public Kyc getSingleUser(Long id) {
			// TODO Auto-generated method stub
			return kycrepository.findById(id).get();
		}
		public void deleteById(Long id) {
			kycrepository.deleteById(id);
		}
		
		

}
