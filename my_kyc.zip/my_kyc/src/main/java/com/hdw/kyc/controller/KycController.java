package com.hdw.kyc.controller;


import java.util.*;

import com.hdw.kyc.service.*;
import com.hdw.kyc.model.Kyc;
import com.hdw.kyc.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
public class KycController {
        @Autowired
        public KycService Kycservice;
        @RequestMapping(method=RequestMethod.POST,value="/users")
        public Kyc addUser(@RequestBody Kyc user)
        {
        System.out.println(user.getEmail());
        System.out.println(user.getUsername());
        System.out.println(user.getPassword());
        System.out.println(user.getAddress());
        System.out.println(user.getId());
        
                return Kycservice.addUser(user);
        }
        
        @RequestMapping("/users/{id}")
        public Kyc getSingleUser(@PathVariable Long id) {
        	return Kycservice.getSingleUser(id);
        }
        
        
        @RequestMapping(method=RequestMethod.PUT,value="/users")
        public Kyc updateUser(@RequestBody Kyc User) {
        	//System.out.println(User.toString());
        	 return Kycservice.updateSingleUser(User);
        	 
        }
        
        
        @RequestMapping("/users")
        public List<Kyc> getAllUsers ()
        {
                
                return  Kycservice.getAllUsers();
        }
        @RequestMapping(method=RequestMethod.DELETE,value="/users/{id}")
        public void deleteById(@PathVariable Long id)
        {
        	 Kycservice.deleteById(id);
        }	
       
}
