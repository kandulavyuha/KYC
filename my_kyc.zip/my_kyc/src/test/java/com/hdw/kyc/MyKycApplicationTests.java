package com.hdw.kyc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyKycApplicationTests {

	@Test
	void contextLoads() {
	}

}
